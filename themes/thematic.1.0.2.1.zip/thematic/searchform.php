<?php
/**
 * Search Form Template
 *
 * …
 * 
 * @package Thematic
 * @subpackage Templates
 */
    
    // calls the search form
	thematic_search_form();
?>